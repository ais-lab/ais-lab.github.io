---
title: RENTERIA ROCHIN Franciscoが学部のページに紹介されました
author: aislab_webstaff
lang: ja
image: 
tags:
  - event
---

AIS Lab. M2のRENTERIA ROCHIN Francisco君が学部のページに紹介されました。

{% capture col1 %}
{% endcapture %}

{% capture col2 %}

{% endcapture %}

{% include cols.html col1=col1 col2=col2 %}