---
title: 李先生がCDOマガジンが発表したLeading Academic Data Leadersに選定されました。
author: aislab_webstaff
lang: ja
image: http://www.aislab.org/wp-content/uploads/2022/05/CDOmagazine-1024x571.png
tags:
  - event
---

李先生がCDO（Chief Data Officer）Magazineが選定した世界のLeading Academic Data Leadersに選ばれました。詳細な内容は以下のリンクからご覧ください。Leading Academic Data Leaders

{% capture col1 %}
{%
  include figure.html
  image="http://www.aislab.org/wp-content/uploads/2022/05/CDOmagazine-1024x571.png"
  width="800px"
%}
{% endcapture %}

{% capture col2 %}

{% endcapture %}

{% include cols.html col1=col1 col2=col2 %}